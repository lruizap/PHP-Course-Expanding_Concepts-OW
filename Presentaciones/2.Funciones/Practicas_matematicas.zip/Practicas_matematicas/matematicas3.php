<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body>
<?php

	//Funciones Matemáticas
	echo(abs(-6.7) . "<br/>");
	
	echo(max(2,4,6,8,10) . "<br/>");
	
	echo(min(2,4,6,8,10) . "<br/>");
	
	echo "<p> </p>";
	
	echo(rand() . "<br/>");
	echo(rand(10,100). "<br/>");
	
	echo "<p> </p>";
	
	echo(sqrt(9) . "<br/>");
	
	echo "<p> </p>";
	
	echo decbin("3") . "<br/>";
	echo decbin("1587") . "<br/>";
	echo dechex("10") . "<br/>";
	echo bindec("1011") . "<br/>";
	
	
?>
</body>
</html>